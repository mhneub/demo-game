﻿using UnityEngine;
using System.Collections;

public class backToMenu : MonoBehaviour {

	public void LoadScene()
	{
		Application.LoadLevel(0);
	}
}
